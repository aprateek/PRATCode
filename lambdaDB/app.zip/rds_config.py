#config file containing credentials for rds mysql instance
db_username = "prateek"
db_password = "pratruchi"
db_name = "exampleDB"
db_endpoint= "pratdbinst.cuahsi78y7vf.ap-south-1.rds.amazonaws.com" 
